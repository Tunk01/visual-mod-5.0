package com.vismod.module;

import com.vismod.module.modules.*;

/**
 * Every module from the reference screenshots gets registered here so the
 * config screen's list/search/pagination matches exactly. A handful are
 * fully implemented (see module/modules/*.java for the patterns to copy);
 * safe entries use CosmeticModule, a shared custom-renderer implementation,
 * while server-sensitive or external-service features are intentionally omitted.
 *
 * To implement one: write a Module subclass following the pattern of
 * ArmorFXModule (tick-based particles), PerformanceModule (HUD overlay),
 * or NametagMixin+FlagModule (mixin-driven), then swap its registration
 * line below. The id string must stay the same so existing players don't
 * lose their saved toggle state.
 */
public final class ModuleRegistry {

    private ModuleRegistry() {}

    public static void registerAll() {
        // ---- fully implemented ----
        ModuleManager.register(new ArmorFXModule());
        ModuleManager.register(new FirePlusModule());
        ModuleManager.register(new PlayerTrailsModule());
        ModuleManager.register(new JumpCirclesModule());
        ModuleManager.register(new HitEffectsModule());
        ModuleManager.register(new PerformanceModule());
        ModuleManager.register(new NowPlayingModule());
        ModuleManager.register(new CustomCrosshairModule());
        ModuleManager.register(new FlagModule("nametags", "Nametags", ModuleCategory.HUD,
                "Show/hide nametags above players and mobs.", true));
        ModuleManager.register(new FlagModule("weather", "Weather", ModuleCategory.WORLD,
                "Show/hide rain and snow rendering.", true));
        ModuleManager.register(new AuroraSkyModule());
        ModuleManager.register(new ShootingStarsModule());

        // ---- shared custom cosmetic implementations ----
        cosmetic("menu_buttons", "Menu Buttons", ModuleCategory.STYLE, "Custom styling for in-game menu buttons.");
        cosmetic("enchant_glint_plus", "Enchant Glint+", ModuleCategory.ENTITIES, "Enhanced enchantment glint shader.");
        cosmetic("cherry_petals", "Cherry Petals", ModuleCategory.WORLD, "Ambient falling cherry petal particles.");
        cosmetic("frost_flakes", "Frost Flakes", ModuleCategory.WORLD, "Ambient falling frost particles in cold biomes.");
        cosmetic("prismatic_bubbles", "Prismatic Bubbles", ModuleCategory.WORLD, "Ambient rising rainbow bubble particles.");
        cosmetic("prism_shards", "Prism Shards", ModuleCategory.WORLD, "Ambient glinting shard particles.");
        cosmetic("wandering_souls", "Wandering Souls", ModuleCategory.ENTITIES, "Soul wisp particles drifting off mobs.");
        cosmetic("fairy_rings", "Fairy Rings", ModuleCategory.WORLD, "Mushroom-ring particle circles in forests.");
        cosmetic("attack_indicator", "Attack Indicator", ModuleCategory.HUD, "Custom attack cooldown indicator.");
        cosmetic("larp", "Larp", ModuleCategory.MISC, "Roleplay flourishes.");
        cosmetic("three_d_swords", "3D Swords", ModuleCategory.STYLE, "Renders held swords in full 3D instead of flat.");
        cosmetic("autumn_leaves", "Autumn Leaves", ModuleCategory.WORLD, "Ambient falling leaf particles.");
        cosmetic("ember_drift", "Ember Drift", ModuleCategory.WORLD, "Drifting ember particles near fire/lava.");
        cosmetic("astral_dust", "Astral Dust", ModuleCategory.WORLD, "Ambient sparkling dust at night.");
        cosmetic("lunar_moths", "Lunar Moths", ModuleCategory.WORLD, "Moth particles that gather near light at night.");
        cosmetic("rune_blooms", "Rune Blooms", ModuleCategory.WORLD, "Glowing rune-shaped flower particles.");
        cosmetic("crystal_gardens", "Crystal Gardens", ModuleCategory.WORLD, "Ambient crystal shard formations.");
        cosmetic("ley_lines", "Ley Lines", ModuleCategory.WORLD, "Glowing energy line overlays across terrain.");
        cosmetic("energy_vortices", "Energy Vortices", ModuleCategory.WORLD, "Swirling energy particle vortices.");
        cosmetic("rift_sparks", "Rift Sparks", ModuleCategory.WORLD, "Spark particles near portals/rifts.");
        cosmetic("anchor_fx", "Anchor FX", ModuleCategory.ENTITIES, "Particle effect on respawn anchor use.");
        cosmetic("fireflies", "Fireflies", ModuleCategory.WORLD, "Ambient firefly particles at night.");
        cosmetic("angel_wings", "Angel Wings", ModuleCategory.ENTITIES, "Cosmetic wing overlay on players.");
        // Omitted: requires external assets/service and is not part of the self-contained cosmetic client.
        // Intentionally omitted: gameplay-information, fake-entity, and freelook features are not server-safe.
        cosmetic("light_pillars", "Light Pillars", ModuleCategory.WORLD, "Vertical light beams on rare drops.");
        cosmetic("orbiting_relics", "Orbiting Relics", ModuleCategory.ENTITIES, "Cosmetic items orbiting the player.");
        cosmetic("player_animations", "Player Animations", ModuleCategory.MOTION, "Extra idle/walk animation flourishes.");
        cosmetic("party", "Party", ModuleCategory.MISC, "Celebration particle bursts for special events.");
        cosmetic("explosion_fx", "ExplosionFX", ModuleCategory.ENTITIES, "Enhanced explosion particles/shockwave.");
        cosmetic("china_hat", "China Hat", ModuleCategory.ENTITIES, "Cosmetic hat overlay.");
        // Omitted: requires external assets/service and is not part of the self-contained cosmetic client.
        // Intentionally omitted: gameplay-information, fake-entity, and freelook features are not server-safe.
        cosmetic("damage_feedback", "Damage Feedback", ModuleCategory.HUD, "Screen-edge flash when you take damage.");
        cosmetic("dropped_items", "Dropped items", ModuleCategory.WORLD, "Enhanced rendering for item entities on the ground.");
        cosmetic("projectiles", "Projectiles", ModuleCategory.ENTITIES, "Enhanced arrow/trident/snowball trails.");
        cosmetic("anchor_shader", "Anchor shader", ModuleCategory.STYLE, "Custom shader applied near respawn anchors.");
        ModuleManager.register(new AmbientNatureModule());
        cosmetic("atmosphere", "Atmosphere", ModuleCategory.WORLD, "Fog/haze density and tint control.");
        cosmetic("color_grading", "Color grading", ModuleCategory.STYLE, "Global post-processing color grade.");

        cosmetic("end_crystals", "End crystals", ModuleCategory.ENTITIES, "Enhanced end crystal beam/particles.");
        cosmetic("experience", "Experience", ModuleCategory.HUD, "Custom XP bar styling.");
        cosmetic("block_highlights", "Block highlights", ModuleCategory.STYLE, "Custom block outline/highlight style.");
        cosmetic("player_effects", "Player effects", ModuleCategory.ENTITIES, "Visual overlay for active status effects.");
        cosmetic("celestial_effects", "Celestial effects", ModuleCategory.WORLD, "Custom sun/moon rendering.");
        cosmetic("hud", "HUD", ModuleCategory.HUD, "Master HUD layout/style toggle.");
        cosmetic("cinematic_menus", "Cinematic menus", ModuleCategory.STYLE, "Animated transitions between menu screens.");
        // Omitted: requires external assets/service and is not part of the self-contained cosmetic client.

        cosmetic("viewmodel", "Viewmodel", ModuleCategory.STYLE, "Held-item viewmodel position/scale/sway.");
        cosmetic("swing_customizer", "Swing Customizer", ModuleCategory.MOTION, "Custom arm swing speed/arc.");
        // Intentionally omitted: gameplay-information, fake-entity, and freelook features are not server-safe.
        cosmetic("totem_particles", "Totem Particles", ModuleCategory.ENTITIES, "Custom totem-of-undying activation particles.");
        // Omitted: requires external assets/service and is not part of the self-contained cosmetic client.
        cosmetic("death_ghosts", "Death Ghosts", ModuleCategory.ENTITIES, "Ghost silhouette at your last death location.");
        cosmetic("custom_fov", "Custom FOV", ModuleCategory.STYLE, "Fine-grained field-of-view control.");
        cosmetic("player_afterimages", "Player Afterimages", ModuleCategory.MOTION, "Motion-blur style afterimages on fast movement.");
        cosmetic("totem_size", "Totem Size", ModuleCategory.STYLE, "Scale of the totem-of-undying pop-up animation.");
        cosmetic("totem_ghosts", "Totem Ghosts", ModuleCategory.ENTITIES, "Ghost trail during totem activation.");
        cosmetic("camera", "Camera", ModuleCategory.MOTION, "Custom camera shake/smoothing settings.");
    }

    private static void cosmetic(String id, String name, ModuleCategory category, String description) {
        ModuleManager.register(new CosmeticModule(id, name, category, description));
    }
}
