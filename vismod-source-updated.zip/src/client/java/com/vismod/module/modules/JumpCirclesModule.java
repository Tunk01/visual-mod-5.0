package com.vismod.module.modules;

import com.vismod.config.ModuleVisualConfig;
import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.render.CustomEffectManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;

import java.util.HashSet;
import java.util.Set;

/** Custom expanding geometric ring at the moment a visible player jumps. */
public class JumpCirclesModule extends Module {
    private static final int RING_POINTS = 12;
    private final Set<Integer> wasOnGround = new HashSet<>();
    public JumpCirclesModule() { super("jump_circles", "Jump Circles", ModuleCategory.MOTION,
            "Custom expanding ring geometry under jumping players.", true); }

    @Override public void onClientTick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (world == null) return;
        ModuleVisualConfig.Settings style = ModuleVisualConfig.get("jump_circles");
        for (PlayerEntity player : world.getPlayers()) {
            int id = player.getId();
            boolean ground = player.isOnGround();
            if (!ground && wasOnGround.contains(id)) spawnRing(world, player, style);
            if (ground) wasOnGround.add(id); else wasOnGround.remove(id);
        }
    }

    private void spawnRing(ClientWorld world, PlayerEntity player, ModuleVisualConfig.Settings style) {
        int points = Math.max(4, Math.min(32, Math.round(RING_POINTS * style.effectCount / 80f)));
        double radius = 0.35 * style.size;
        for (int i = 0; i < points; i++) {
            double angle = Math.PI * 2 * i / points;
            CustomEffectManager.emit("jump_circles", CustomEffectManager.Type.RING,
                    player.getX() + Math.cos(angle) * radius, player.getY() + 0.05,
                    player.getZ() + Math.sin(angle) * radius, 0, 0.02, 0, 22, 0.12f);
        }
    }
    @Override protected void onDisable(MinecraftClient client) { wasOnGround.clear(); }
}