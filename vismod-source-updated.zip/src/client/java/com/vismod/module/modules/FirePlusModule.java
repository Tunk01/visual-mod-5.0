package com.vismod.module.modules;

import com.vismod.config.ModuleVisualConfig;
import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.render.CustomEffectManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.random.Random;

/** Custom flame and smoke geometry for burning entities; no vanilla particles are used. */
public class FirePlusModule extends Module {
    private final Random random = Random.create();
    public FirePlusModule() { super("fire_plus", "Fire+", ModuleCategory.ENTITIES,
            "Custom flame shards, ember diamonds, and smoke cards around burning entities.", true); }

    @Override public void onClientTick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (world == null) return;
        ModuleVisualConfig.Settings style = ModuleVisualConfig.get("fire_plus");
        if (style.nightOnly && !world.isNight()) return;
        for (Entity entity : world.getEntities()) {
            if (!entity.isOnFire()) continue;
            int count = Math.max(1, Math.min(10, Math.round(style.effectCount / 24f)));
            for (int i = 0; i < count; i++) {
                double spread = entity.getWidth() * (0.5 + style.size);
                CustomEffectManager.emit("fire_plus", CustomEffectManager.Type.FLAME,
                        entity.getX() + (random.nextDouble() - 0.5) * spread,
                        entity.getY() + random.nextDouble() * entity.getHeight() * 1.2,
                        entity.getZ() + (random.nextDouble() - 0.5) * spread,
                        0, 0.035, 0, 18, 0.16f);
            }
            if (random.nextFloat() < style.opacity) {
                CustomEffectManager.emit("fire_plus", CustomEffectManager.Type.SMOKE,
                        entity.getX(), entity.getY() + entity.getHeight() * 0.8, entity.getZ(), 0, 0.025, 0, 36, 0.26f);
            }
        }
    }
}