package com.vismod.module.modules;

import com.vismod.config.ModuleVisualConfig;
import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.render.CustomEffectManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

import java.util.HashMap;
import java.util.Map;

/** Custom impact shards on visible health changes; no vanilla crit particles. */
public class HitEffectsModule extends Module {
    private final Map<Integer, Float> lastHealth = new HashMap<>();
    public HitEffectsModule() { super("hit_effects", "Hit Effects", ModuleCategory.ENTITIES,
            "Custom impact shards whenever a visible entity takes damage.", true); }

    @Override public void onClientTick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (world == null) return;
        ModuleVisualConfig.Settings style = ModuleVisualConfig.get("hit_effects");
        for (Entity entity : world.getEntities()) {
            if (!(entity instanceof LivingEntity living)) continue;
            float current = living.getHealth();
            Float previous = lastHealth.put(entity.getId(), current);
            if (previous != null && current < previous) {
                int count = Math.max(2, Math.min(20, Math.round(6f * style.effectCount / 80f)));
                for (int i = 0; i < count; i++) {
                    CustomEffectManager.emit("hit_effects", CustomEffectManager.Type.SPARK,
                            living.getX(), living.getY() + living.getHeight() * 0.5, living.getZ(),
                            (world.random.nextDouble() - 0.5) * 0.3, world.random.nextDouble() * 0.2,
                            (world.random.nextDouble() - 0.5) * 0.3, 22, 0.14f);
                }
            }
        }
    }
    @Override protected void onDisable(MinecraftClient client) { lastHealth.clear(); }
}