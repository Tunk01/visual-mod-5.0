package com.vismod.gui.widget;

import com.vismod.config.VisualConfig;
import com.vismod.module.Module;
import com.vismod.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;

/** Frosted glass module row with a quiet, compact toggle treatment. */
public class ModuleRow extends ClickableWidget {
    private static final int STAR_SIZE = 10;
    private static final int TOGGLE_WIDTH = 30;
    private static final int TOGGLE_HEIGHT = 14;
    private final Module module;

    public ModuleRow(Module module, int x, int y, int width, int height) {
        super(x, y, width, height, Text.literal(module.displayName()));
        this.module = module;
    }
    public Module module() { return module; }

    @Override
    protected void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        MinecraftClient client = MinecraftClient.getInstance();
        boolean hovered = isHovered();
        int background = hovered ? 0xA0243040 : 0x78141D2A;
        com.vismod.render.GlassRenderer.panel(context, getX(), getY(), getWidth(), getHeight(), background,
                (hovered ? 0xB0 : 0x55) << 24 | (VisualConfig.get().animatedPrimaryColor() & 0x00FFFFFF));

        int starX = getX() + 8;
        int starY = getY() + (getHeight() - STAR_SIZE) / 2;
        boolean starHovered = isOver(mouseX, mouseY, starX, starY, STAR_SIZE, STAR_SIZE);
        int starColor = module.isStarred() ? 0xFFFFC86B : (starHovered ? 0xFFE8F7FF : 0xFF667788);
        context.drawTextWithShadow(client.textRenderer, module.isStarred() ? "★" : "☆", starX, starY, starColor);

        int textX = starX + STAR_SIZE + 8;
        int textY = getY() + (getHeight() - 8) / 2;
        int nameColor = module.isEnabled() ? 0xFFF3FAFF : 0xFFAAB8C4;
        context.drawTextWithShadow(client.textRenderer, module.displayName(), textX, textY, nameColor);
        int toggleX = getX() + getWidth() - TOGGLE_WIDTH - 8;
        int toggleY = getY() + (getHeight() - TOGGLE_HEIGHT) / 2;
        context.drawTextWithShadow(client.textRenderer, "⚙", toggleX - 17, getY() + (getHeight() - 8) / 2,
                isOver(mouseX, mouseY, toggleX - 18, getY(), 14, getHeight()) ? 0xFFFFFFFF : 0xFF71808E);
        drawTogglePill(context, toggleX, toggleY, module.isEnabled());
    }

    private void drawTogglePill(DrawContext context, int x, int y, boolean on) {
        int track = on ? ((0xD0 << 24) | (VisualConfig.get().accentColor() & 0x00FFFFFF)) : 0x80506070;
        context.fill(x, y, x + TOGGLE_WIDTH, y + TOGGLE_HEIGHT, track);
        int knob = TOGGLE_HEIGHT - 4;
        int knobX = on ? x + TOGGLE_WIDTH - knob - 2 : x + 2;
        context.fill(knobX, y + 2, knobX + knob, y + 2 + knob, 0xFFF5FCFF);
    }

    @Override public void onClick(Click click, boolean doubleClick) {
        int mx = (int) click.x(), my = (int) click.y();
        int starX = getX() + 8, starY = getY() + (getHeight() - STAR_SIZE) / 2;
        if (isOver(mx, my, starX, starY, STAR_SIZE, STAR_SIZE)) { ModuleManager.setStarred(module, !module.isStarred()); return; }
        int toggleX = getX() + getWidth() - TOGGLE_WIDTH - 8;
        int toggleY = getY() + (getHeight() - TOGGLE_HEIGHT) / 2;
        if (isOver(mx, my, toggleX - 18, getY(), 14, getHeight())) { module.openSettings(MinecraftClient.getInstance()); return; }
        if (isOver(mx, my, toggleX, toggleY, TOGGLE_WIDTH, TOGGLE_HEIGHT)) { ModuleManager.setEnabled(module, !module.isEnabled()); return; }
        if (module.hasExtraSettings()) module.openSettings(MinecraftClient.getInstance());
    }

    private boolean isOver(int mx, int my, int x, int y, int w, int h) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }
    @Override protected void appendClickableNarrations(net.minecraft.client.gui.screen.narration.NarrationMessageBuilder builder) { builder.put(net.minecraft.client.gui.screen.narration.NarrationPart.TITLE, getMessage()); }
}