package com.vismod.gui.widget;

import com.vismod.config.ModuleVisualConfig;
import com.vismod.render.GlassRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;

import java.util.Locale;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;

/** Compact click-to-position slider styled like the supplied module settings reference. */
public class ModuleSlider extends ClickableWidget {
    private final String label;
    private final double min;
    private final double max;
    private final DoubleSupplier getter;
    private final DoubleConsumer setter;

    public ModuleSlider(String label, int x, int y, int width, int height, double min, double max,
                        DoubleSupplier getter, DoubleConsumer setter) {
        super(x, y, width, height, Text.literal(label));
        this.label = label;
        this.min = min;
        this.max = max;
        this.getter = getter;
        this.setter = setter;
    }

    @Override
    protected void renderWidget(DrawContext context, int mouseX, int mouseY, float delta) {
        MinecraftClient client = MinecraftClient.getInstance();
        double value = Math.max(min, Math.min(max, getter.getAsDouble()));
        float progress = (float) ((value - min) / (max - min));
        int railY = getY() + getHeight() - 7;
        context.drawTextWithShadow(client.textRenderer, label, getX(), getY(), 0xDDEAF5FF);
        context.drawTextWithShadow(client.textRenderer, format(value), getX() + getWidth() - 38, getY(), 0xFFFFFFFF);
        context.fill(getX(), railY, getX() + getWidth(), railY + 2, 0x70485A6A);
        int activeWidth = Math.max(2, (int) (getWidth() * progress));
        context.fill(getX(), railY, getX() + activeWidth, railY + 2,
                (0xE0 << 24) | (com.vismod.config.VisualConfig.get().animatedPrimaryColor() & 0x00FFFFFF));
        int knobX = getX() + activeWidth - 4;
        context.fill(knobX, railY - 3, knobX + 8, railY + 5, 0xFFF1FAFF);
    }

    private String format(double value) {
        if (Math.abs(value - Math.rint(value)) < 0.01) return Integer.toString((int) Math.rint(value));
        return String.format(Locale.ROOT, "%.2f", value);
    }

    @Override public void onClick(Click click, boolean doubleClick) {
        double progress = Math.max(0.0, Math.min(1.0, (click.x() - getX()) / (double) getWidth()));
        setter.accept(min + progress * (max - min));
        ModuleVisualConfig.save();
    }

    @Override protected void appendClickableNarrations(net.minecraft.client.gui.screen.narration.NarrationMessageBuilder builder) {
        builder.put(net.minecraft.client.gui.screen.narration.NarrationPart.TITLE, getMessage());
    }
}