package com.vismod.gui;

import com.vismod.config.VisualConfig;
import com.vismod.gui.widget.GlassButton;
import com.vismod.render.GlassRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.text.Text;

/** Floating, draggable, resizable glass pause window. */
public class CompactPauseScreen extends Screen {
    private int panelWidth = 340;
    private int panelHeight = 220;
    private int panelX;
    private int panelY;
    private boolean draggingTop;
    private double dragOffsetX;
    private double dragOffsetY;

    public CompactPauseScreen() { super(Text.literal("VisMod Pause")); }

    private void placeDefault() {
        if (panelX == 0 && panelY == 0) {
            panelX = width / 2 - panelWidth / 2;
            panelY = height / 2 - panelHeight / 2;
        }
        panelX = Math.max(12, Math.min(width - panelWidth - 12, panelX));
        panelY = Math.max(12, Math.min(height - panelHeight - 12, panelY));
    }

    @Override protected void init() {
        placeDefault();
        rebuildButtons();
    }

    private void rebuildButtons() {
        clearChildren();
        int buttonWidth = Math.min(300, panelWidth - 40);
        int left = panelX + (panelWidth - buttonWidth) / 2;
        int top = panelY + 70;
        addDrawableChild(GlassButton.of(left, top, buttonWidth, 28,
                Text.literal("Resume session"), button -> close()));
        int half = (buttonWidth - 8) / 2;
        addDrawableChild(GlassButton.of(left, top + 36, half, 26,
                Text.literal("Visuals"), button -> client.setScreen(new VisualsConfigScreen(this))));
        addDrawableChild(GlassButton.of(left + half + 8, top + 36, half, 26,
                Text.literal("Options"), button -> client.setScreen(new OptionsScreen(this, client.options))));
        addDrawableChild(GlassButton.of(left, top + 70, buttonWidth, 26,
                Text.literal("Leave world / server"), button -> {
                    client.disconnect();
                    client.setScreen(new CustomTitleScreen());
                }));
    }

    private boolean inTopBar(double mouseX, double mouseY) {
        return mouseX >= panelX && mouseX <= panelX + panelWidth
                && mouseY >= panelY && mouseY <= panelY + 42;
    }

    @Override public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && inTopBar(mouseX, mouseY)) {
            draggingTop = true;
            dragOffsetX = mouseX - panelX;
            dragOffsetY = mouseY - panelY;
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0) draggingTop = false;
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (draggingTop && button == 0) {
            panelX = (int) Math.round(mouseX - dragOffsetX);
            panelY = (int) Math.round(mouseY - dragOffsetY);
            placeDefault();
            rebuildButtons();
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (draggingTop && inTopBar(mouseX, mouseY)) {
            int change = (int) Math.round(verticalAmount * 18.0);
            panelWidth = Math.max(300, Math.min(520, panelWidth + change));
            panelHeight = Math.max(200, Math.min(340, panelHeight + change * 2 / 3));
            placeDefault();
            rebuildButtons();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        placeDefault();
        GlassRenderer.blurBackdrop(context);
        context.fill(0, 0, width, height, 0x180A1018);

        // Multiple low-alpha layers create depth while preserving the world behind the glass.
        GlassRenderer.panel(context, panelX - 4, panelY - 4, panelWidth + 8, panelHeight + 8, 0x241B8CFF, 0x305DE8FF);
        GlassRenderer.panel(context, panelX, panelY, panelWidth, panelHeight, 0x72101828, 0xB8DDF5FF);
        GlassRenderer.panel(context, panelX + 7, panelY + 7, panelWidth - 14, 34, 0x321D3146, 0x4694C4E8);
        context.drawTextWithShadow(textRenderer, "PAUSED", panelX + 18, panelY + 16, VisualConfig.get().primaryColor());
        context.drawTextWithShadow(textRenderer, "drag top bar  •  scroll while holding to resize", panelX + 18, panelY + 31, 0xB8D9E8F4);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override public void close() { if (client != null) client.setScreen(null); }
    @Override public boolean shouldPause() { return true; }
}