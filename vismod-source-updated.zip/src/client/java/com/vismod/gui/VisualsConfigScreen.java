package com.vismod.gui;

import com.vismod.config.VisualConfig;
import com.vismod.gui.widget.GlassButton;
import com.vismod.gui.widget.ModuleRow;
import com.vismod.module.Module;
import com.vismod.module.ModuleCategory;
import com.vismod.module.ModuleManager;
import com.vismod.render.GlassRenderer;
import com.vismod.render.VisModBackdrop;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Scrollable rounded-glass module dashboard. */
public class VisualsConfigScreen extends Screen {
    private enum Filter { ALL, ENTITIES, MOTION, STARRED }
    private static final int ROW_HEIGHT = 22;
    private final Screen parent;
    private TextFieldWidget searchBox;
    private Filter filter = Filter.ALL;
    private int scrollRows;
    private List<Module> filtered = new ArrayList<>();
    private final List<ModuleRow> activeRows = new ArrayList<>();

    public VisualsConfigScreen(Screen parent) { super(Text.literal("VisMod Visuals")); this.parent = parent; }
    private int panelX() { return width / 2 - 390; }
    private int panelY() { return 30; }
    private int panelHeight() { return Math.max(360, height - 60); }
    private int listTop() { return panelY() + 88; }
    private int footerY() { return panelY() + panelHeight() - 34; }
    private int visibleRows() { return Math.max(8, Math.min(18, (footerY() - listTop() - 12) / ROW_HEIGHT)); }
    private int maxScrollRows() { return Math.max(0, (filtered.size() + 1) / 2 - visibleRows()); }

    @Override protected void init() {
        int x = panelX(), y = panelY();
        String[] tabs = {"Visuals", "Presets", "World", "HUD", "Style", "Configs", "Setup"};
        int tx = x + 18;
        for (String tab : tabs) {
            int w = textRenderer.getWidth(tab) + 22;
            addDrawableChild(GlassButton.of(tx, y + 16, w, 20, Text.literal(tab), button -> {
                if (tab.equals("Style")) client.setScreen(new VisualSettingsScreen(this));
            }));
            tx += w + 5;
        }
        searchBox = new TextFieldWidget(textRenderer, x + 505, y + 16, 220, 20, Text.literal("Search"));
        searchBox.setPlaceholder(Text.literal("Search modules"));
        searchBox.setChangedListener(text -> { scrollRows = 0; refreshFiltered(); });
        addDrawableChild(searchBox);

        int chipX = x + 18;
        for (Filter f : Filter.values()) {
            String label = f.name().charAt(0) + f.name().substring(1).toLowerCase(Locale.ROOT);
            int w = textRenderer.getWidth(label) + 20;
            addDrawableChild(GlassButton.of(chipX, y + 52, w, 18, Text.literal(label), button -> {
                filter = f; scrollRows = 0; refreshFiltered();
            }));
            chipX += w + 5;
        }
        addDrawableChild(GlassButton.of(x + 730, y + 16, 28, 20, Text.literal("×"), button -> close()));
        refreshFiltered();
    }

    private void refreshFiltered() {
        String query = searchBox == null ? "" : searchBox.getText().toLowerCase(Locale.ROOT);
        filtered = ModuleManager.all().stream().filter(this::matchesFilter)
                .filter(m -> query.isEmpty() || m.displayName().toLowerCase(Locale.ROOT).contains(query)).toList();
        scrollRows = Math.max(0, Math.min(scrollRows, maxScrollRows()));
        rebuildRows();
    }

    private boolean matchesFilter(Module m) {
        return switch (filter) {
            case ALL -> true;
            case ENTITIES -> m.category() == ModuleCategory.ENTITIES;
            case MOTION -> m.category() == ModuleCategory.MOTION;
            case STARRED -> m.isStarred();
        };
    }

    private void rebuildRows() {
        for (ModuleRow row : activeRows) remove(row);
        activeRows.clear();
        int x = panelX() + 18, start = scrollRows * 2, rows = visibleRows();
        for (int i = 0; i < rows * 2 && start + i < filtered.size(); i++) {
            int column = i / rows, row = i % rows;
            ModuleRow widget = new ModuleRow(filtered.get(start + i), x + column * 370, listTop() + row * ROW_HEIGHT, 360, ROW_HEIGHT - 3);
            activeRows.add(widget);
            addDrawableChild(widget);
        }
    }

    @Override public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (mouseX >= panelX() && mouseX <= panelX() + 780 && mouseY >= listTop() && mouseY <= footerY()) {
            scrollRows = Math.max(0, Math.min(maxScrollRows(), scrollRows - (int) Math.signum(verticalAmount)));
            rebuildRows();
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        VisModBackdrop.draw(context, width, height, System.currentTimeMillis());
        int x = panelX(), y = panelY(), h = panelHeight();
        GlassRenderer.panel(context, x, y, 780, h, 0xB00E1420, 0x78FFFFFF);
        context.drawTextWithShadow(textRenderer, "VISMOD", x + 18, y - 18, VisualConfig.get().primaryColor());
        context.drawTextWithShadow(textRenderer, "VISUAL MODULES  /  GLASS CONTROL DECK", x + 78, y - 18, 0xB0D9EFFF);
        context.drawTextWithShadow(textRenderer, "SCROLL TO EXPLORE", x + 610, y - 18, 0x909FB7C8);
        super.render(context, mouseX, mouseY, delta);

        int totalRows = Math.max(1, (filtered.size() + 1) / 2);
        int trackTop = listTop(), trackBottom = footerY() - 10, trackHeight = Math.max(20, trackBottom - trackTop);
        context.fill(x + 764, trackTop, x + 767, trackBottom, 0x454B6070);
        int thumbHeight = Math.max(18, trackHeight * visibleRows() / totalRows);
        int thumbY = trackTop + (trackHeight - thumbHeight) * scrollRows / Math.max(1, maxScrollRows());
        context.fill(x + 763, thumbY, x + 768, thumbY + thumbHeight, 0xD08FE8FF);
        String footer = ModuleManager.enabledCount() + " enabled   •   " + ModuleManager.totalCount() + " modules   •   " + (scrollRows + 1) + "/" + Math.max(1, maxScrollRows() + 1);
        context.drawTextWithShadow(textRenderer, footer, x + 18, footerY(), 0xB0D9EFFF);
    }

    @Override public void close() { if (client != null) client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
}