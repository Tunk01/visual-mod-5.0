package com.vismod.gui;

import com.vismod.config.VisualConfig;
import com.vismod.gui.widget.GlassButton;
import com.vismod.render.GlassRenderer;
import com.vismod.render.VisModBackdrop;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Live controls for the shared client-only visual profile. */
public class VisualSettingsScreen extends Screen {
    private final Screen parent;
    private final VisualConfig settings = VisualConfig.get();

    public VisualSettingsScreen(Screen parent) {
        super(Text.literal("VisMod Style Studio"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int panelX = width / 2 - 190;
        int top = height / 2 - 120;
        addDrawableChild(GlassButton.of(panelX, top, 92, 22, Text.literal("Back"), button -> close()));
        addDrawableChild(GlassButton.of(panelX + 100, top, 180, 22, Text.literal("Palette: " + settings.palette.name()), button -> {
            settings.cyclePalette();
            clearAndInit();
        }));
        addDrawableChild(GlassButton.of(panelX, top + 42, 280, 22, Text.literal("Intensity: " + format(settings.intensity)), button -> {
            settings.intensity = next(settings.intensity, 0.25f, 3.0f);
            VisualConfig.save(); clearAndInit();
        }));
        addDrawableChild(GlassButton.of(panelX, top + 72, 280, 22, Text.literal("Particle density: " + format(settings.particleDensity)), button -> {
            settings.particleDensity = next(settings.particleDensity, 0.25f, 3.0f);
            VisualConfig.save(); clearAndInit();
        }));
        addDrawableChild(GlassButton.of(panelX, top + 102, 280, 22, Text.literal("Animation speed: " + format(settings.animationSpeed)), button -> {
            settings.animationSpeed = next(settings.animationSpeed, 0.25f, 3.0f);
            VisualConfig.save(); clearAndInit();
        }));
        addDrawableChild(GlassButton.of(panelX, top + 132, 136, 22, Text.literal("Glow: " + onOff(settings.glow)), button -> {
            settings.glow = !settings.glow; VisualConfig.save(); clearAndInit();
        }));
        addDrawableChild(GlassButton.of(panelX + 144, top + 132, 136, 22, Text.literal("Rainbow: " + onOff(settings.rainbow)), button -> {
            settings.rainbow = !settings.rainbow; VisualConfig.save(); clearAndInit();
        }));
        addDrawableChild(GlassButton.of(panelX, top + 162, 280, 22, Text.literal("Menu opacity: " + format(settings.menuOpacity)), button -> {
            settings.menuOpacity = next(settings.menuOpacity, 0.1f, 1.0f);
            VisualConfig.save(); clearAndInit();
        }));
        addDrawableChild(GlassButton.of(panelX, top + 198, 280, 22, Text.literal("Crosshair size: " + settings.crosshairSize), button -> {
            settings.crosshairSize = settings.crosshairSize >= 20 ? 4 : settings.crosshairSize + 4;
            VisualConfig.save(); clearAndInit();
        }));
        addDrawableChild(GlassButton.of(panelX, top + 230, 280, 22, Text.literal("Reset style"), button -> {
            settings.intensity = 1.0f; settings.particleDensity = 1.0f; settings.animationSpeed = 1.0f;
            settings.menuOpacity = 0.72f; settings.glow = true; settings.rainbow = false;
            settings.palette = VisualConfig.Palette.CYBER; settings.crosshairColor = 0xFF8FE8FF; settings.crosshairSize = 8;
            VisualConfig.save(); clearAndInit();
        }));
    }

    private float next(float value, float step, float max) {
        float next = value + step;
        return next > max + 0.01f ? step : next;
    }

    private String format(float value) { return String.format(java.util.Locale.ROOT, "%.2fx", value); }
    private String onOff(boolean value) { return value ? "ON" : "OFF"; }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        VisModBackdrop.draw(context, width, height, System.currentTimeMillis());
        int panelX = width / 2 - 205;
        int top = height / 2 - 142;
        GlassRenderer.panel(context, panelX, top, 410, 420, 0xB000101C, 0x70FFFFFF);
        context.drawCenteredTextWithShadow(textRenderer, "STYLE STUDIO", width / 2, top + 14, settings.primaryColor());
        context.drawCenteredTextWithShadow(textRenderer, "Every control is local, cosmetic, and server-safe", width / 2, top + 28, 0xA0D9EFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override public void close() { if (client != null) client.setScreen(parent); }
    @Override public boolean shouldPause() { return false; }
}