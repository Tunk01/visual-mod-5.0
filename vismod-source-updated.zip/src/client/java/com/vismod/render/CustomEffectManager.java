package com.vismod.render;

import com.vismod.config.ModuleVisualConfig;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * VisMod's own lightweight effect layer. It draws animated geometry directly
 * through the world render queue and never creates Minecraft particle entities.
 */
public final class CustomEffectManager {
    public enum Type { TRAIL, RING, SPARK, FLAME, SMOKE, AURA, DUST, BEAM }

    private static final List<Effect> EFFECTS = new ArrayList<>();
    private static boolean initialized;

    private static final class Effect {
        final String moduleId;
        final Type type;
        double x, y, z, vx, vy, vz;
        final int life;
        int age;
        final float size;
        final float opacity;
        final int primary;
        final int highlight;

        Effect(String moduleId, Type type, double x, double y, double z,
               double vx, double vy, double vz, int life, float size,
               float opacity, int primary, int highlight) {
            this.moduleId = moduleId; this.type = type;
            this.x = x; this.y = y; this.z = z;
            this.vx = vx; this.vy = vy; this.vz = vz;
            this.life = life; this.size = size; this.opacity = opacity;
            this.primary = primary; this.highlight = highlight;
        }
    }

    private CustomEffectManager() {}

    public static void init() {
        if (initialized) return;
        initialized = true;
        ClientTickEvents.END_CLIENT_TICK.register(client -> tick());
        WorldRenderEvents.AFTER_ENTITIES.register(CustomEffectManager::render);
    }

    public static void emit(String moduleId, Type type, double x, double y, double z,
                            double vx, double vy, double vz, int lifeTicks, float size) {
        ModuleVisualConfig.Settings style = ModuleVisualConfig.get(moduleId);
        int life = Math.max(2, (int) (lifeTicks / Math.max(0.1f, style.animationSpeed)));
        EFFECTS.add(new Effect(moduleId, type, x, y, z, vx, vy, vz, life,
                Math.max(0.05f, size * style.size), style.opacity,
                style.primaryColor, style.highlightColor));
        if (EFFECTS.size() > 900) EFFECTS.subList(0, EFFECTS.size() - 900).clear();
    }

    private static void tick() {
        Iterator<Effect> iterator = EFFECTS.iterator();
        while (iterator.hasNext()) {
            Effect effect = iterator.next();
            effect.age++;
            effect.x += effect.vx;
            effect.y += effect.vy;
            effect.z += effect.vz;
            effect.vx *= 0.985;
            effect.vy *= 0.985;
            effect.vz *= 0.985;
            if (effect.age >= effect.life) iterator.remove();
        }
    }

    private static void render(WorldRenderContext context) {
        if (EFFECTS.isEmpty()) return;
        Vec3d camera = context.camera().getPos();
        for (Effect effect : List.copyOf(EFFECTS)) {
            float progress = effect.age / (float) effect.life;
            context.commandQueue().submitCustom(context.matrices(), RenderLayers.debugQuads(),
                    (matrix, vertices) -> draw(vertices, matrix, effect, camera, progress));
        }
    }

    private static void draw(VertexConsumer vertices, MatrixStack.Entry matrix, Effect e,
                             Vec3d camera, float progress) {
        float fade = Math.min(1f, progress * 7f) * Math.min(1f, (1f - progress) * 5f);
        float pulse = 0.78f + 0.22f * (float) Math.sin((e.age + e.moduleId.hashCode() % 13) * 0.45);
        float alpha = Math.max(0f, Math.min(1f, fade * pulse * e.opacity));
        int color = lerpRgb(e.primary, e.highlight, (float) (0.5 + 0.5 * Math.sin(e.age * 0.18)));
        float red = ((color >> 16) & 255) / 255f;
        float green = ((color >> 8) & 255) / 255f;
        float blue = (color & 255) / 255f;
        Vector3f p = new Vector3f((float) (e.x - camera.x), (float) (e.y - camera.y), (float) (e.z - camera.z));
        float s = e.size * (0.65f + progress * 0.55f);

        switch (e.type) {
            case RING -> ring(vertices, matrix, p, s, red, green, blue, alpha);
            case FLAME -> diamond(vertices, matrix, p, s * 0.9f, red, green, blue, alpha);
            case SMOKE -> square(vertices, matrix, p, s * 1.35f, red, green, blue, alpha * 0.62f);
            case AURA -> aura(vertices, matrix, p, s, red, green, blue, alpha);
            case SPARK -> spark(vertices, matrix, p, s, red, green, blue, alpha);
            case TRAIL, DUST -> diamond(vertices, matrix, p, s * 0.7f, red, green, blue, alpha);
            case BEAM -> beam(vertices, matrix, p, s, red, green, blue, alpha);
        }
    }

    private static void ring(VertexConsumer v, MatrixStack.Entry m, Vector3f p, float s, float r, float g, float b, float a) {
        for (int i = 0; i < 8; i++) {
            double angle = Math.PI * 2 * i / 8.0;
            float x = p.x + (float) Math.cos(angle) * s;
            float z = p.z + (float) Math.sin(angle) * s;
            diamond(v, m, new Vector3f(x, p.y, z), s * 0.28f, r, g, b, a);
        }
    }

    private static void aura(VertexConsumer v, MatrixStack.Entry m, Vector3f p, float s, float r, float g, float b, float a) {
        diamond(v, m, new Vector3f(p.x, p.y + s, p.z), s * 0.55f, r, g, b, a);
        diamond(v, m, new Vector3f(p.x, p.y, p.z), s * 0.34f, g, b, r, a * 0.8f);
    }

    private static void beam(VertexConsumer v, MatrixStack.Entry m, Vector3f p, float s, float r, float g, float b, float a) {
        float height = s * 12.0f;
        diamond(v, m, new Vector3f(p.x, p.y + height * 0.5f, p.z), s * 0.45f, r, g, b, a * 0.7f);
        square(v, m, new Vector3f(p.x, p.y + height * 0.5f, p.z), s * 0.12f, r, g, b, a);
    }

    private static void spark(VertexConsumer v, MatrixStack.Entry m, Vector3f p, float s, float r, float g, float b, float a) {
        square(v, m, p, s * 0.45f, r, g, b, a);
        square(v, m, new Vector3f(p.x, p.y + s, p.z), s * 0.22f, b, r, g, a);
    }

    private static void diamond(VertexConsumer v, MatrixStack.Entry m, Vector3f p, float s, float r, float g, float b, float a) {
        vertex(v, m, p.x, p.y + s, p.z, r, g, b, a);
        vertex(v, m, p.x + s, p.y, p.z, r, g, b, a * 0.75f);
        vertex(v, m, p.x, p.y - s, p.z, r, g, b, a * 0.45f);
        vertex(v, m, p.x - s, p.y, p.z, r, g, b, a * 0.75f);
        vertex(v, m, p.x, p.y + s, p.z, r, g, b, a);
    }

    private static void square(VertexConsumer v, MatrixStack.Entry m, Vector3f p, float s, float r, float g, float b, float a) {
        vertex(v, m, p.x - s, p.y - s, p.z, r, g, b, a);
        vertex(v, m, p.x + s, p.y - s, p.z, r, g, b, a);
        vertex(v, m, p.x + s, p.y + s, p.z, r, g, b, a * 0.7f);
        vertex(v, m, p.x - s, p.y + s, p.z, r, g, b, a * 0.7f);
        vertex(v, m, p.x - s, p.y - s, p.z, r, g, b, a);
    }

    private static void vertex(VertexConsumer v, MatrixStack.Entry m, float x, float y, float z,
                               float r, float g, float b, float a) {
        v.vertex(m, new Vector3f(x, y, z)).color(r, g, b, a);
    }

    private static int lerpRgb(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return ((int) (ar + (br - ar) * t) << 16)
                | ((int) (ag + (bg - ag) * t) << 8)
                | (int) (ab + (bb - ab) * t);
    }
}