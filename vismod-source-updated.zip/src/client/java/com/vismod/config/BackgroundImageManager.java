package com.vismod.config;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Lets the player import their own title-screen background (the "Theme"
 * button). The chosen file's path is remembered in
 * config/vismod/background.txt so it persists across restarts; the image
 * itself is uploaded as a dynamic texture the first time it's needed.
 */
public final class BackgroundImageManager {

    public static final Identifier TEXTURE_ID = Identifier.of("vismod", "custom_title_background");

    private static final Path PATH_FILE = FabricLoader.getInstance().getConfigDir()
            .resolve("vismod").resolve("background.txt");

    private static boolean loaded = false;
    private static boolean available = false;

    private BackgroundImageManager() {}

    public static boolean hasCustomBackground() {
        if (!loaded) {
            tryLoadSaved();
        }
        return available;
    }

    public static Identifier textureId() {
        return TEXTURE_ID;
    }

    /** Opens a native file chooser off-thread, then uploads the chosen image on the render thread. */
    public static void promptAndLoad(Runnable onDone) {
        new Thread(() -> {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Choose a title screen background");
            chooser.setFileFilter(new FileNameExtensionFilter("Images", "png", "jpg", "jpeg"));
            int result = chooser.showOpenDialog(null);
            if (result == JFileChooser.APPROVE_OPTION) {
                File file = chooser.getSelectedFile();
                MinecraftClient.getInstance().execute(() -> {
                    loadFromFile(file.toPath());
                    savePath(file.toPath());
                    if (onDone != null) onDone.run();
                });
            }
        }, "vismod-file-chooser").start();
    }

    private static void tryLoadSaved() {
        loaded = true;
        try {
            if (Files.exists(PATH_FILE)) {
                String raw = Files.readString(PATH_FILE, StandardCharsets.UTF_8).trim();
                if (!raw.isEmpty()) {
                    Path path = Path.of(raw);
                    if (Files.exists(path)) {
                        loadFromFile(path);
                    }
                }
            }
        } catch (IOException ignored) {
            // no saved background yet, that's fine
        }
    }

    private static void loadFromFile(Path path) {
        try (var in = Files.newInputStream(path)) {
            NativeImage image = NativeImage.read(in);
                MinecraftClient.getInstance().getTextureManager()
                    .registerTexture(TEXTURE_ID,
                        new NativeImageBackedTexture(() -> "vismod_background", image));
                available = true;
        } catch (IOException e) {
            System.err.println("[VisMod] Failed to load custom background: " + e);
        }
    }

    private static void savePath(Path path) {
        try {
            Files.createDirectories(PATH_FILE.getParent());
            Files.writeString(PATH_FILE, path.toAbsolutePath().toString(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            System.err.println("[VisMod] Failed to save background path: " + e);
        }
    }
}
