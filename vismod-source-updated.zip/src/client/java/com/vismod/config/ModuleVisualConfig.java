package com.vismod.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** Independent cosmetic controls for every module. Saved locally and never sent to servers. */
public final class ModuleVisualConfig {
    public static final class Settings {
        public int effectCount = 80;
        public int spawnRadius = 14;
        public float size = 1.0f;
        public float animationSpeed = 1.0f;
        public float opacity = 0.80f;
        public boolean nightOnly = false;
        public int primaryColor = 0xFF8FE8FF;
        public int highlightColor = 0xFFB58CFF;
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type TYPE = new TypeToken<HashMap<String, Settings>>() {}.getType();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("vismod").resolve("module-visuals.json");
    private static Map<String, Settings> values;

    private ModuleVisualConfig() {}

    public static Settings get(String moduleId) {
        if (values == null) load();
        return values.computeIfAbsent(moduleId, id -> new Settings());
    }

    public static void load() {
        values = new HashMap<>();
        try {
            if (Files.exists(FILE)) {
                try (Reader reader = Files.newBufferedReader(FILE, StandardCharsets.UTF_8)) {
                    Map<String, Settings> parsed = GSON.fromJson(reader, TYPE);
                    if (parsed != null) values.putAll(parsed);
                }
            }
        } catch (IOException | RuntimeException ignored) {}
    }

    public static void save() {
        if (values == null) return;
        try {
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE, StandardCharsets.UTF_8)) {
                GSON.toJson(values, TYPE, writer);
            }
        } catch (IOException ignored) {}
    }

    public static void reset(String moduleId) {
        if (values == null) load();
        values.put(moduleId, new Settings());
        save();
    }

    public static void clamp(Settings s) {
        s.effectCount = Math.max(1, Math.min(240, s.effectCount));
        s.spawnRadius = Math.max(2, Math.min(48, s.spawnRadius));
        s.size = clamp(s.size, 0.25f, 3.0f);
        s.animationSpeed = clamp(s.animationSpeed, 0.10f, 3.0f);
        s.opacity = clamp(s.opacity, 0.05f, 1.0f);
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}